﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiChzk1.Transfer
{
    public class Countrydt
    {
        public string country1 { get; set; }
        public string description { get; set; }
        public string timezone { get; set; }

    }
}