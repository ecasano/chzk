﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiChzk1.Transfer
{
    public class Modedt
    {
        public string mode1 { get; set; }
        public string description { get; set; }
    }
}