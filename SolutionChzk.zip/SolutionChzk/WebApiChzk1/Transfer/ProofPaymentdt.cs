﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiChzk1.Transfer
{
    public class ProofPaymentdt
    {
        public string proofPayment1 { get; set; }
        public string description { get; set; }
    }
}