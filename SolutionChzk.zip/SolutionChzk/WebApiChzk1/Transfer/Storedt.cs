﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApiChzk1.Transfer
{
    public class Storedt
    {

        public int storeId { get; set; }

        public string district { get; set; }

        public string reference { get; set; }
    }
}